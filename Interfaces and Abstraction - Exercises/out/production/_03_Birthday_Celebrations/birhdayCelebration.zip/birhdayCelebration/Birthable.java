package birhdayCelebration;

public interface Birthable
{
    String getBirthDate();
}
