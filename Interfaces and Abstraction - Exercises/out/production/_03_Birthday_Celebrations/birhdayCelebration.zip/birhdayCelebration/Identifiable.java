package birhdayCelebration;

public interface Identifiable
{
    String getId();
}
