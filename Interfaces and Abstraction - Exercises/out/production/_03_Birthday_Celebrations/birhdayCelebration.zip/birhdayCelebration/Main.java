package birhdayCelebration;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main
{
    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);
        List<Birthable> citizensAndPets = new ArrayList<>();

        String command = scanner.nextLine();

        while(!command.equals("End"))
        {
            String[] comArgs = command.split(" ");
            if(comArgs[0].equals("Citizen"))
            {
                addNewCitizen(citizensAndPets, comArgs);
            }
            else if(comArgs[0].equals("Pet"))
            {
                addNewPet(citizensAndPets, comArgs);
            }
            else if(comArgs[0].equals("Robot"))
            {
                //Robot {model} {id}
                String model = comArgs[1];
                String id = comArgs[2];
                Robot robot = new Robot(id, model);
            }
            command = scanner.nextLine();
        }
        String number = scanner.nextLine();
        printCorrectBirthDates(citizensAndPets, number);


    }
    public static void addNewCitizen(List<Birthable> citizensAndPets, String[] comArgs)
    {
        //Citizen {name} {age} {id} {birthdate}
        String name = comArgs[1];
        int age = Integer.parseInt(comArgs[2]);
        String id = comArgs[3];
        String birthdate = comArgs[4];
        Citizen citizen = new Citizen(name, age, id, birthdate);
        citizensAndPets.add(citizen);
    }
    public static void addNewPet(List<Birthable> citizensAndPets, String[] comArgs)
    {
        //Pet {name} {birthdate}
        String name = comArgs[1];
        String birthdate = comArgs[2];
        Pet pet = new Pet(name, birthdate);
        citizensAndPets.add(pet);
    }
    public static void printCorrectBirthDates(List<Birthable> items,  String number)
    {
        int counter = 0;
        for(Birthable item : items)
        {
            if(item.getBirthDate().endsWith(number))
            {
                System.out.println(item.getBirthDate());
                counter++;
            }
        }
        if(counter == 0)
        {
            System.out.println("<no output>");
        }
    }

}