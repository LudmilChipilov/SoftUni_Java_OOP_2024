package inheritanceFour;

import java.util.ArrayList;
import java.util.Stack;

public class StackOfStrings
{
    private ArrayList<String> data;
    public StackOfStrings()
    {
        this.data = new ArrayList<>();
    }

    public ArrayList<String> getData() {
        return data;
    }

    public void setData(ArrayList<String> data) {
        this.data = data;
    }
    public void push(String item)
    {
        data.addLast(item);
    }
    public String pop()
    {
        if(isEmpty())
        {
            return null;
        }
        String element = data.getLast();
        data.removeLast();
        return element;
    }
    public String  peek()
    {
        if(!isEmpty())
        {
            return data.getLast();
        }
        return null;
    }
    public boolean isEmpty()
    {
        if(data.isEmpty())
        {
            return true;
        }
        return false;
    }
}
