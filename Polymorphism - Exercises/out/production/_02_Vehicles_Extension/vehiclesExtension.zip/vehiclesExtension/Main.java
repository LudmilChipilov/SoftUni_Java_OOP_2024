package vehiclesExtension;

import java.text.DecimalFormat;
import java.util.Scanner;

public class Main
{
    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);
        final double nonEmptyBusFuelConsumption = 1.4;

        String[] carInfo = scanner.nextLine().split("\\s+");
        Vehicle car = new Car(Double.parseDouble(carInfo[1]), Double.parseDouble(carInfo[2]), Double.parseDouble(carInfo[3]));
        String[] truckInfo = scanner.nextLine().split("\\s+");
        Vehicle truck = new Truck(Double.parseDouble(truckInfo[1]), Double.parseDouble(truckInfo[2]), Double.parseDouble(truckInfo[3]));
        String[] busInfo = scanner.nextLine().split("\\s+");
        Vehicle bus = new Bus(Double.parseDouble(busInfo[1]), Double.parseDouble(busInfo[2]), Double.parseDouble(busInfo[3]));
        int number = Integer.parseInt(scanner.nextLine());
        for(int i = 0; i < number; i++)
        {
            String[] commands = scanner.nextLine().split("\\s+");
            String command = commands[0];
            if(command.equals("Drive"))
            {
                driveVehicle(car, truck, bus, commands, nonEmptyBusFuelConsumption);
            }
            else if(command.equals("DriveEmpty"))
            {
                driveEmptyBus(bus, commands);
            }
            else if(command.equals("Refuel"))
            {

                refuelVehicle(car, truck, bus, commands);
            }
        }
       printFinalState(car, truck, bus);
    }
    public static void driveVehicle(Vehicle car,  Vehicle truck, Vehicle bus, String[] commands, double nonEmptyBusFuelConsumption)
    {
        String vehicleType = commands[1];
        double distance = Double.parseDouble(commands[2]);
        if(vehicleType.equals("Car"))
        {
            if(checkIfCurrentFuelIsPositive(car.getFuelQuantity() - car.getLitersPerKm()*distance, vehicleType))
            {
                car.setFuelQuantity(car.getFuelQuantity() -  car.getLitersPerKm()*distance);
                printVehicleTravelledDistance(vehicleType, distance);
            }
        }
        else if(vehicleType.equals("Truck"))
        {
            if(checkIfCurrentFuelIsPositive(truck.getFuelQuantity() - truck.getLitersPerKm()*distance, vehicleType))
            {
                truck.setFuelQuantity(truck.getFuelQuantity() -  truck.getLitersPerKm()*distance);
                printVehicleTravelledDistance(vehicleType, distance);
            }
        }
        else if(vehicleType.equals("Bus"))
        {
            if(checkIfCurrentFuelIsPositive(bus.getFuelQuantity() - ((bus.getLitersPerKm() + nonEmptyBusFuelConsumption)*distance), vehicleType))
            {
                bus.setFuelQuantity(bus.getFuelQuantity() -  ((bus.getLitersPerKm() + nonEmptyBusFuelConsumption)*distance));
                printVehicleTravelledDistance(vehicleType, distance);
            }
        }
    }
    public static void driveEmptyBus(Vehicle bus, String[] commands)
    {
        double distance = Double.parseDouble(commands[2]);
        double fuelState = bus.getFuelQuantity() - bus.getLitersPerKm()*distance;
        if(checkIfCurrentFuelIsPositive(fuelState, "Bus"))
        {
            bus.setFuelQuantity(fuelState);
            printVehicleTravelledDistance("Bus", distance);
        }

    }
    public static void refuelVehicle(Vehicle car,  Vehicle truck, Vehicle bus, String[] commands)
    {
        String vehicleType = commands[1];
        double litersFuel = Double.parseDouble(commands[2]);
        if(checkAndPrintIfCurrentFuelIsValid(litersFuel, vehicleType))
        {
            if(vehicleType.equals("Car"))
            {
                if(!checkIfFuelRefueledIsMoreThanTankCapacity(car.getFuelQuantity() + litersFuel, car))
                {
                    car.setFuelQuantity(car.getFuelQuantity() + litersFuel);
                }

            }
            else if(vehicleType.equals("Truck"))
            {
                if(!checkIfFuelRefueledIsMoreThanTankCapacity(truck.getFuelQuantity() + litersFuel, truck))
                {
                    truck.setFuelQuantity(truck.getFuelQuantity() + litersFuel);
                }

            }
            else if(vehicleType.equals("Bus"))
            {
                if(!checkIfFuelRefueledIsMoreThanTankCapacity(bus.getFuelQuantity() + litersFuel, bus))
                {
                    bus.setFuelQuantity(bus.getFuelQuantity() + litersFuel);
                }

            }
        }


    }

    public static boolean checkIfCurrentFuelIsPositive(double fuel, String vehicleType)
    {
        if(fuel <= 0)
        {
            System.out.printf("%s needs refueling%n", vehicleType);
            return false;
        }
        return true;
    }
    public static boolean checkAndPrintIfCurrentFuelIsValid(double fuel, String vehicleType)
    {
        if(fuel <= 0)
        {
            System.out.println("Fuel must be a positive number");
            return false;
        }
        return true;
    }
    public static void printVehicleTravelledDistance(String vehicleType, double distance)
    {
        DecimalFormat decimalFormat = new DecimalFormat("#.##");
        System.out.printf("%s travelled %s km%n", vehicleType, decimalFormat.format(distance));
    }
    public static void printFinalState(Vehicle car,  Vehicle truck, Vehicle bus)
    {
        System.out.printf("Car: %.2f%n", car.getFuelQuantity());
        System.out.printf("Truck: %.2f%n", truck.getFuelQuantity());
        System.out.printf("Bus: %.2f%n", bus.getFuelQuantity());

    }
    public static boolean checkIfFuelRefueledIsMoreThanTankCapacity(double fuel, Vehicle vehicle)
    {
           if(fuel > vehicle.getTankCapacity())
           {
               System.out.println("Cannot fit fuel in tank");
               return true;
           }
           return false;
    }
}