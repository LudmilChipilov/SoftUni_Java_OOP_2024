package vehiclesExtension;

public class Bus extends Vehicle
{

    protected Bus(double fuelQuantity, double litersPerKm, double tankCapacity)
    {
        super(fuelQuantity, litersPerKm, tankCapacity);
    }

}
