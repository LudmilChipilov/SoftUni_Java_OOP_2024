package sayHelloExtended;

public interface Person
{
    public String getName();
    public String sayHello();
}
