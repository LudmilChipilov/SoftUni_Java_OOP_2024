package classBox;

import java.security.InvalidParameterException;

public class Box
{
    private double length;
    private double width;
    private double height;

    public Box(double length, double width, double height)
    {
        this.setLength(length);
        this.setWidth(width);
        this.setHeight(height);
    }

    public double getLength() {
        return length;
    }

    public void setLength(double length)
    {
        if(length <= 0)
        {
            throw new InvalidParameterException("Length cannot be zero or negative.");
        }
        this.length = length;
    }

    public double getWidth() {
        return width;
    }

    public void setWidth(double width)
    {
        if(width <= 0)
        {
            throw new InvalidParameterException("Width cannot be zero or negative.");
        }
        this.width = width;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height)
    {
        if(height <= 0)
        {
            throw new InvalidParameterException("Hight cannot be zero or negative.");
        }
        this.height = height;
    }

     public Double calculateSurfaceArea ()
     {
         return 2 * ((length * height) + (width * height)) + 2 * (length * width);
     }
    public Double calculateLateralSurfaceArea ()
    {
        return 2 * ((length * height) + (width * height));
    }
    public Double calculateVolume ()
    {
        return length * width * height;
    }
}
